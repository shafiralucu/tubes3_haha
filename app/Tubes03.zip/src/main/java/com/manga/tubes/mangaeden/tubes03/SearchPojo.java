package com.manga.tubes.mangaeden.tubes03;

public class SearchPojo  {
    String title;
    String id;
    String img;
    public SearchPojo(){

    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
